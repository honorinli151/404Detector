# Description

This tool recognize 404 error according to the html content.
Useful when using Selenium webdriver.
You need to first train the model using the dataset given in ./data

# Dependencies

    pip install ./wm-dist/*.tar.gz