# coding: utf-8

class HashableDict(dict):
    def __hash__(self):
        return hash(tuple(sorted(self.items())))

def hashableDictListToDictList(hashableDictList):
    results = []
    for current in hashableDictList:
        results.append(hashableDictToDict(current))
    return results

def hashableDictToDict(hashableDict):
    result = dict()
    for key, value in hashableDict.items():
        result[key] = value
    return result



if __name__ == '__main__':
    pass